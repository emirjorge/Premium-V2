#!/bin/bash
# 25/01/2021 by @Emir Jorge
 hihyV="0.4.9"
 function echoColor() {
 	case $1 in
 		# ROJO
 	"red")
 		echo -e "\033[31m${printN}$2 \033[0m"
 		;;
 		# CELESTE
 	"skyBlue")
 		echo -e "\033[1;36m${printN}$2 \033[0m"
 		;;
 		# VERDE
 	"green")
 		echo -e "\033[32m${printN}$2 \033[0m"
 		;;
 		# BLANCO
 	"white")
 		echo -e "\033[37m${printN}$2 \033[0m"
 		;;
 		# MAGENTA
 	"magenta")
 		echo -e "\033[31m${printN}$2 \033[0m"
 		;;
 		# AMARILLO
 	"yellow")
 		echo -e "\033[33m${printN}$2 \033[0m"
 		;;
        # PURPURA
    "purple")
        echo -e "\033[1;;35m${printN}$2 \033[0m"
        ;;
        #
    "yellowBlack")
        # AMARILLO FONDO NEGRO
        echo -e "\033[1;33;40m${printN}$2 \033[0m"
        ;;
	"greenWhite")
		# BLANCO FONDO VERDE
		echo -e "\033[42;37m${printN}$2 \033[0m"
		;;
 	esac
 }
 
 function checkSystemForUpdate() {
 	if [[ -n $(find /etc -name "redhat-release") ]] || grep </proc/version -q -i "centos"; then
 		mkdir -p /etc/yum.repos.d
 
 		if [[ -f "/etc/centos-release" ]]; then
 			centosVersion=$(rpm -q centos-release | awk -F "[-]" '{print $3}' | awk -F "[.]" '{print $1}')
 
 			if [[ -z "${centosVersion}" ]] && grep </etc/centos-release -q -i "release 8"; then
 				centosVersion=8
 			fi
 		fi
 		release="centos"
 		installType='yum -y -q install'
 		removeType='yum -y -q remove'
 		upgrade="yum update -y  --skip-broken"
 
 	elif grep </etc/issue -q -i "debian" && [[ -f "/etc/issue" ]] || grep </etc/issue -q -i "debian" && [[ -f "/proc/version" ]]; then
		release="debian"
 		installType='apt -y -q install'
 		upgrade="apt update"
 		updateReleaseInfoChange='apt-get --allow-releaseinfo-change update'
 		removeType='apt -y -q autoremove'
 
 	elif grep </etc/issue -q -i "ubuntu" && [[ -f "/etc/issue" ]] || grep </etc/issue -q -i "ubuntu" && [[ -f "/proc/version" ]]; then
 		release="ubuntu"
 		installType='apt -y -q install'
 		upgrade="apt update"
 		updateReleaseInfoChange='apt-get --allow-releaseinfo-change update'
 		removeType='apt -y -q autoremove'
 		if grep </etc/issue -q -i "16."; then
 			release=
 		fi
 	fi
 
 	if [[ -z ${release} ]]; then
 		echoColor red "\nEste script no es compatible con este sistema. Envíe el siguiente registro al desarrollador\n"
 		echoColor yellow "$(cat /etc/issue)"
 		echoColor yellow "$(cat /proc/version)"
 		exit 0
 	fi
    echoColor purple "\nUpdate.wait..."
    ${upgrade}
 	if ! [ -x "$(command -v wget)" ]; then
 		echoColor green "*wget"
 		${installType} "wget"
 	fi
 	if ! [ -x "$(command -v curl)" ]; then
 		echoColor green "*curl"
 		${installType} "curl"
 	fi
 	if ! [ -x "$(command -v lsof)" ]; then
 		echoColor green "*lsof"
 		${installType} "lsof"
 	fi
 	if ! [ -x "$(command -v dig)" ]; then
 		echoColor green "*dnsutils"
 		if [[ ${release} == "centos" ]]; then
 			${installType} "bind-utils"
 		else
 			${installType} "dnsutils"
 		fi
 	fi
    echoColor purple "\nDone."
    
 }

 function uninstall(){
	rm -r /usr/bin/hihy
    bash <(curl -fsSL https://git.io/rmhysteria.sh)
 }

 function reinstall(){
    bash <(curl -fsSL https://git.io/rehysteria.sh)
 }

 function printMsg(){
	msg=`cat /etc/hihy/conf/hihy.conf | grep "remarks"`
	remarks=${msg#*:}
	cp -P /etc/hihy/result/hihyClient.json ./Hys-${remarks}\(v2rayN\).json
	cp -P /etc/hihy/result/metaHys.yaml ./Hys-${remarks}\(clashMeta\).yaml
	echoColor yellow "--------------------------------------------"
	echo ""
	echo -e  "\033[1;;35m1* [\033[0m\033[31mv2rayN/Matsuri/nekobox/nekoray\033[0m\033[1;;35m] Ejecutar directamente hysteria core: \033[0m"
	echoColor green "Los archivos de configuración del cliente se envían a: `pwd`/Hys-${remarks}(v2rayN).json ( Descargue directamente el archivo de configuración generado [recomendado]
 / Copie y pegue la siguiente configuración en su computadora local )"
	echoColor green "Tips: El cliente solo se abre por defecto http(10809)、socks5(10808)¡Agente! Consulte otros métodos hysteria Cliente de automodificación de documentos config.json"
	echoColor skyBlue "↓***********************************↓↓↓copy↓↓↓*******************************↓"
	cat ./Hys-${remarks}\(v2rayN\).json
	echoColor skyBlue "↑***********************************↑↑↑copy↑↑↑*******************************↑\n"
	url=`cat /etc/hihy/result/url.txt`
	echo -e  "\033[1;;35m2* [\033[0m\033[31mShadowrocket/Matsuri/nekobox/Passwall\033[0m\033[1;;35m] 一 Enlace clave: \033[0m"
	echoColor green ${url}
	echo -e "\n"
	echo -e  "\033[1;;35m3* [\033[0m\033[31mClash.Meta\033[0m\033[1;;35m] El archivo de configuración ya está en `pwd`/Hys-${remarks}(clashMeta).yaml producción,Descargue al cliente para su uso(beta)\033[0m"
	echoColor yellow "--------------------------------------------"
 }

 function hihy(){
	if [ ! -f "/usr/bin/hihy" ]; then
  		wget -q -O /usr/bin/hihy --no-check-certificate https://raw.githubusercontent.com/emirjorge/Premium-V2/master/Hysteria/server/hysteria.sh
		chmod +x /usr/bin/hihy
	fi	
 }

 function changeIp64(){
    if [ ! -f "/etc/hihy/conf/hihyServer.json" ]; then
  		echoColor red "No instalado correctamente hihy!"
        exit
	fi 
	now=`cat /etc/hihy/conf/hihyServer.json | grep "resolve_preference"`
    case ${now} in 
		*"64"*)
			echoColor purple "actual ipv6 tiene prioridad"
            echoColor yellow " \n->configuración ipv4 Prioridad superior a ipv6?(Y/N,por defecto N)"
            read input
            if [ -z "${input}" ];then
                echoColor green "Ignore."
                exit
            else
                sed -i 's/"resolve_preference": "64"/"resolve_preference": "46"/g' /etc/hihy/conf/hihyServer.json
                systemctl restart hihy
                echoColor green "Done.Ipv4 first now."
            fi
            
		;;
		*"46"*)
			echoColor purple "actual ipv4 tiene prioridad"
            echoColor yellow " \n->configuración ipv6 Prioridad superior a ipv4?(Y/N,por defecto N)"
            read input
            if [ -z "${input}" ];then
                echoColor green "Ignore."
                exit
            else
                sed -i 's/"resolve_preference": "46",/"resolve_preference": "64",/g' /etc/hihy/conf/hihyServer.json
                systemctl restart hihy
                echoColor green "Done.Ipv6 first now."
            fi
        ;;
	esac
 }

 function getPortBindMsg(){
        # $1 type UDP or TCP
        # $2 port
		if [ $1 == "UDP" ]; then
        	msg=`lsof -i ${1}:${2}`
		else
			msg=`lsof -i ${1}:${2} | grep LISTEN`
		fi
        if [ "${msg}" == "" ];then
                return
        else	
				command=`echo ${msg} | awk '{print $1}'`
  				pid=`echo ${msg} | awk '{print $2}'`
  				name=`echo ${msg} | awk '{print $9}'`
          		echoColor purple "Port: ${1}/${2} Ha sido ${command}(${name}) ocupado,proceso pid para: ${pid}."
  				echoColor green "Cerrar automáticamente la ocupación del puerto?(y/N)"
				read bindP
				if [ -z "${bindP}" ];then
					echoColor red "porque el puerto esta ocupado，Salga de la instalación. Por favor cierre o cambie el puerto manualmente..."
					if [ "${1}" == "TCP" ] && [ "${2}" == "80" ];then
						echoColor "Si no se puede cerrar por demanda ${1}/${2}puerto，Utilice otros métodos de adquisición de certificados"
					fi
					exit
				elif [ "${bindP}" == "y" ] ||  [ "${bindP}" == "Y" ];then
					kill -9 ${pid}
					echoColor purple "Desvinculando..."
					sleep 3
					if [ $1 == "TCP" ]; then
						msg=`lsof -i ${1}:${2} | grep LISTEN`
					else
						msg=`lsof -i ${1}:${2}`
					fi
        			if [ "${msg}" != "" ];then
						echoColor red "No se pudo cerrar la ocupación del puerto,Reinicie el proceso después de forzarlo a cerrar,Por favor verifique si hay un proceso activo..."
						exit
					else
						echoColor green "Desvinculación del puerto exitoso..."
					fi
				else
					echoColor red "Salga de la instalación porque el puerto está ocupado. Por favor cierre o cambie el puerto manualmente..."
					if [ "${1}" == "TCP" ] && [ "${2}" == "80" ];then
						echoColor "Si no se puede cerrar si es necesario ${1}/${2}puerto，Utilice otros métodos de adquisición de certificados"
					fi
					exit
				fi
        fi
 }

 function setHysteriaConfig(){
	mkdir -p /etc/hihy/bin /etc/hihy/conf /etc/hihy/cert  /etc/hihy/result /etc/hihy/acl
	echoColor yellowBlack "Iniciar configuración:"
	echo -e "\033[32mPor favor seleccione el método de solicitud del certificado:\n\n\033[0m\033[33m\033[01m1、usar ACME aplicar(recomendado,requiere abrir tcp 80/443)\n2、Usar archivo de certificado local\n3、certificado autofirmado\033[0m\033[32m\n\nIngrese número de serie:\033[0m"
    read certNum
	useAcme=false
	useLocalCert=false
	if [ -z "${certNum}" ] || [ "${certNum}" == "3" ];then
		echo -e  "\nAviso: Cuando el certificado autofirmado no tiene obfs en el período reciente, tiene muchos bloques aleatorios"
		echoColor red "Si debe utilizar un certificado autofirmado, configure la verificación de ofuscación obfs en la configuración siguiente para garantizar la seguridad."
		echoColor green "Introduzca el nombre de dominio del certificado autofirmado (por defecto: wechat.com):"
		read domain
		if [ -z "${domain}" ];then
			domain="wechat.com"
		fi
		echo -e "->El nombre de dominio del certificado autofirmado es:"`echoColor red ${domain}`"\n"
		ip=`curl -4 -s -m 8 ip.sb`
		if [ -z "${ip}" ];then
			ip=`curl -s -m 8 ip.sb`
		fi
		echoColor green "¿Determinar si la dirección utilizada por el cliente para conectarse es correcta? red publica ip:"`echoColor red ${ip}`"\n"
		while true
		do	
			echo -e "\033[32mPor favor elige:\n\n\033[0m\033[33m\033[01m1、correcto (predeterminado)\n2、Incorrecto, Ingresar IP manual\033[0m\033[32m\n\nIngrese número de serie:\033[0m"
			read ipNum
			if [ -z "${ipNum}" ] || [ "${ipNum}" == "1" ];then
				break
			elif [ "${ipNum}" == "2" ];then
				echoColor green "Por favor ingresa la red pública correcta ip(ipv6 No es necesario agregar dirección[]):"
				read ip
				if [ -z "${ip}" ];then
					echoColor red "error de entrada,por favor ingresa nuevamente..."
					continue
				fi
				break
			else
				echoColor red "\n->Error de entrada, vuelva a ingresar:"
			fi
		done		
		cert="/etc/hihy/cert/${domain}.crt"
		key="/etc/hihy/cert/${domain}.key"
		useAcme=false
		echoColor purple "\n\n->Has elegido autofirmar ${domain}Cifrado de certificado red pública ip:"`echoColor red ${ip}`"\n"
		echo -e "\n"
    elif [ "${certNum}" == "2" ];then
		echoColor green "Por favor ingrese la ruta del archivo del certificado(Se requiere fullchain cert,Proporcionar cadena de certificados completa):"
		read cert
		while :
		do
			if [ ! -f "${cert}" ];then
				echoColor red "\n\n->La ruta no existe, por favor vuelve a ingresar!"
				echoColor green "Por favor ingrese la ruta del archivo cert del certificado:"
				read  cert
			else
				break
			fi
		done
		echo -e "\n\n->ruta del archivo cert: "`echoColor red ${cert}`"\n"
		echoColor green "Ingrese la ruta del archivo key del certificado:"
		read key
		while :
		do
			if [ ! -f "${key}" ];then
				echoColor red "\n\n->La ruta no existe, por favor vuelve a ingresar!"
				echoColor green "Ingrese la ruta del archivo key del certificado:"
				read  key
			else
				break
			fi
		done
		echo -e "\n\n->ruta del archivo key: "`echoColor red ${key}`"\n"
		echoColor green "Por favor ingrese el nombre de dominio del certificado seleccionado:"
		read domain
		while :
		do
			if [ -z "${domain}" ];then
				echoColor red "\n\n->Esta opción no puede estar vacía, ¡vuelve a ingresar!"
				echoColor green "Introduzca el nombre de dominio del certificado seleccionado:"
				read  domain
			else
				break
			fi
		done
		useAcme=false
		useLocalCert=true
		echoColor purple "\n\n->Ha seleccionado el cifrado de certificado local. Nombre de dominio:"`echoColor red ${domain}`"\n"
    else 
    	echoColor green "Por favor ingrese el nombre de dominio(Debe analizarse correctamente en la máquina local y CDN debe estar desactivado):"
		read domain
		while :
		do
			if [ -z "${domain}" ];then
				echoColor red "\n\n->Esta opción no puede estar vacía, por favor vuelve a ingresar!"
				echoColor green "Por favor ingrese el nombre de dominio(Debe analizarse correctamente en la máquina local y CDN debe estar desactivado):"
				read  domain
			else
				break
			fi
		done
		while :
		do	
			echoColor purple "\n->Detección${domain},Resolución DNS..."
			ip_resolv=`dig +short ${domain} A`
			if [ -z "${ip_resolv}" ];then
				ip_resolv=`dig +short ${domain} AAAA`
			fi
			if [ -z "${ip_resolv}" ];then
				echoColor red "\n\n->Falló la resolución del nombre de dominio,No se obtuvieron registros DNS (A/AAAA). ¡Compruebe si el nombre de dominio está resuelto correctamente en esta máquina!"
				echoColor green "Por favor ingrese el nombre de dominio(Debe analizarse correctamente en la máquina local,Desactivar CDN):"
				read  domain
				continue
			fi
			remoteip=`echo ${ip_resolv} | awk -F " " '{print $1}'`
			v6str=":" #Is ipv6?
			result=$(echo ${remoteip} | grep ${v6str})
			if [ "${result}" != "" ];then
				localip=`curl -6 -s -m 8 ip.sb`
			else
				localip=`curl -4 -s -m 8 ip.sb`
			fi
			if [ -z "${localip}" ];then
				localip=`curl -s -m 8 ip.sb` #Si el ip.sb anterior falla,verifíquelo por última vez
				if [ -z "${localip}" ];then
					echoColor red "\n\n->No se pudo obtener la IP local, verifique la conexión de red! curl -s -m 8 ip.sb"
					exit 1
				fi
			fi
			if [ "${localip}" != "${remoteip}" ];then
				echo -e " \n\n->IP local: "`echoColor red ${localip}`" \n\n->dirección IP del nombre de dominio: "`echoColor red ${remoteip}`"\n"
				echoColor green "La detección puede fallar cuando varias IP o DNS no están vigentes. Si está seguro de que la máquina local está resuelta correctamente, ¿desea especificar la IP local usted mismo? [y/N]:"
				read isLocalip
				if [ "${isLocalip}" == "y" ];then
					echoColor green "Por favor ingrese su propia dirección IP:"
					read localip
					while :
					do
						if [ -z "${localip}" ];then
							echoColor red "\n\n->Esta opción no puede estar vacía, ¡vuelve a ingresar!"
							echoColor green "Por favor ingrese su IP local:"
							read  localip
						else
							break
						fi
					done
				fi
				if [ "${localip}" != "${remoteip}" ];then
					echoColor red "\n\n->La IP resuelta por el nombre de dominio no coincide con la IP local, ¡vuelva a ingresar!"
					echoColor green "Por favor ingrese el nombre de dominio(Debe analizarse correctamente en la máquina local, desactivar CDN):"
					read  domain
					continue
				else
					break
				fi
			else
				break
			fi
		done
		useAcme=true
		echoColor purple "\n\n->analizado correctamente, utilice el ACME integrado de Hysteria para solicitar un certificado y un nombre de dominio:"`echoColor red ${domain}`"\n"
    fi

    echo -e "\033[32mSeleccionar tipo de protocolo:\n\n\033[0m\033[33m\033[01m1、udp(QUIC,Habilitar salto de puerto)\n2、faketcp\n3、wechat-video(por defecto)\033[0m\033[32m\n\nIngrese número de opcion:\033[0m"
    read protocol
	ut=
    if [ -z "${protocol}" ] || [ $protocol == "3" ];then
		protocol="wechat-video"
		ut="udp"
    elif [ $protocol == "2" ];then
		protocol="faketcp"
		ut="tcp"
    else 
    	protocol="udp"
		ut="udp"
    fi
    echo -e "\n->Protocolo de transferencia:"`echoColor red ${protocol}`"\n"

	while :
	do
		echoColor green "Por favor ingrese el puerto que desea abrir,este puerto es el puerto del server,sugerencia 10000-65535.(Aleatorio predeterminado)"
		read  port
		if [ -z "${port}" ];then
			port=$(($(od -An -N2 -i /dev/random) % (65534 - 10001) + 10001))
			echo -e "\n->Usar puerto aleatorio:"`echoColor red ${ut}/${port}`"\n"
		else
			echo -e "\n->El puerto que ingresaste:"`echoColor red ${ut}/${port}`"\n"
		fi
		if [ "${port}" -gt 65535 ];then
			echoColor red "El rango de puertos es incorrecto, ¡Vuelva a ingresar!"
			continue
		fi
		if [ "${ut}" != "udp" ];then
			pIDa=`lsof -i ${ut}:${port} | grep "LISTEN" | grep -v "PID" | awk '{print $2}'`
		else
			pIDa=`lsof -i ${ut}:${port} | grep -v "PID" | awk '{print $2}'`
		fi
		if [ "$pIDa" != "" ];
		then
			echoColor red "\n->El puerto ${port} está ocupado,PID:${pIDa}¡Vuelva a ingresar o ejecute kill -9 ${pIDa} y reinstale!"
		else
			break
		fi
		
	done
	clientPort="${port}"
	if [ "${protocol}" == "udp" ];then
		echoColor green "\n->Se detecta que seleccionó el protocolo UDP, puede usar [Salto de puerto/Puertos múltiples],recomendado usar (Port Hopping)[Salto de puerto]"
		echo -e "Tip: Los operadores bloquean/QoS/interrumpen fácilmente las conexiones UDP de un solo puerto a largo plazo, habilitar esta función puede evitar eficazmente este problema."
		echo -e "Para una introducción más detallada, consulte: https://github.com/emptysuns/Hi_Hysteria/blob/main/md/portHopping.md\n"
		echo -e "\033[32mElija si desea habilitar:\n\n\033[0m\033[33m\033[01m1、Habilitado (predeterminado)\n2、Omitir\033[0m\033[32m\n\nIngrese una opcion:\033[0m"
		read portHoppingStatus
		if [ -z "${portHoppingStatus}" ] || [ $portHoppingStatus == "1" ];then
			portHoppingStatus="true"
			echoColor purple "\n->Eliges habilitar el salto de puerto/Función multipuerto(Port Hopping)"
			echo -e "La función de salto de puerto/multipuerto(Port Hopping)requiere ocupar varios puertos,asegúrese de que estos puertos no estén siendo usados en otros servicios.\nTip: El número de puertos seleccionados no debe ser demasiado,se recomienda seleccionar alrededor de 1000, entre 1 y 65535. Se recomienda seleccionar un rango de puertos continuo.\n"
			while :
			do
				echoColor green "Ingrese el puerto de inicio (predeterminado 47000):"
				read  portHoppingStart
				if [ -z "${portHoppingStart}" ];then
					portHoppingStart=47000
				fi
				if [ $portHoppingStart -gt 65535 ];then
					echoColor red "\n->El rango de puertos es incorrecto. ¡Vuelva a ingresar!"
					continue
				fi
				echo -e "\n->puerto de inicio:"`echoColor red ${portHoppingStart}`"\n"
				echoColor green "Ingrese el puerto final (predeterminado 48000):"
				read  portHoppingEnd
				if [ -z "${portHoppingEnd}" ];then
					portHoppingEnd=48000
				fi
				if [ $portHoppingEnd -gt 65535 ];then
					echoColor red "\n->El rango de puertos es incorrecto. ¡Vuelva a ingresar!"
					continue
				fi
				echo -e "\n->puerto final:"`echoColor red ${portHoppingEnd}`"\n"
				if [ $portHoppingStart -ge $portHoppingEnd ];then
					echoColor red "\n->El puerto de inicio debe ser más pequeño que el puerto final. ¡Vuelva a ingresar!"
				else
					break
				fi
			done
			clientPort="${port},${portHoppingStart}-${portHoppingEnd}"
			echo -e "\n->Los parámetros de salto de puerto/multipuerto(Port Hopping) que seleccionó son: "`echoColor red ${portHoppingStart}:${portHoppingEnd}`"\n"
		else
			portHoppingStatus="false"
			echoColor red "\n->Usted elige omitir la función de salto de puerto/multipuerto (Port Hopping)"
		fi
	fi

    echoColor green "Por favor ingrese su ping promedio en este servidor,reelevante para la velocidad de reenvío (predeterminado 200, unidad:ms):"
    read  delay
    if [ -z "${delay}" ];then
		delay=200
    fi
	echo -e "\n->Demora:`echoColor red ${delay}`ms\n"
    echo -e "\nVelocidad esperada, esta es la velocidad máxima del cliente, el servidor no está limitado de forma predeterminada"`echoColor red Tips: El script automáticamente *1.10 hará redundancia. Si sus expectativas son demasiado bajas o demasiado altas, afectará la eficiencia del reenvío. ¡Por favor complete la información con sinceridad!`
    echoColor green "Ingrese la velocidad de descarga promedio esperada por el cliente:(predeterminado 50,unidad:mbps):"
    read  download
    if [ -z "${download}" ];then
        download=50
    fi
	echo -e "\n->Velocidad de descarga del cliente: "`echoColor red ${download}`"mbps\n"
    echo -e "\033[32mIngrese la velocidad de subida promedio esperada del cliente(predeterminado 10,unidad:mbps):\033[0m" 
    read  upload
    if [ -z "${upload}" ];then
        upload=10
    fi
	echo -e "\n->Velocidad de enlace de subida del cliente: "`echoColor red ${upload}`"mbps\n"
	echoColor green "Ingrese la contraseña de autenticación (generada aleatoriamente de forma predeterminada,se recomienda una contraseña segura de más de 20 caracteres):"
	read auth_secret
	if [ -z "${auth_secret}" ];then
		auth_secret=`tr -cd '0-9A-Za-z' < /dev/urandom | fold -w50 | head -n1`
	fi
	echo -e "\n->Contraseña de autenticación:"`echoColor red ${auth_secret}`"\n"
	auth_str=""
	obfs_str=""
	echo -e "Tips: Si se utiliza el cifrado de ofuscación obfs, la capacidad antibloqueo es más fuerte y puede identificarse como tráfico UDP desconocido, pero aumentará la carga de la CPU y hará que la velocidad máxima disminuya. No recomendado si buscas rendimiento y no estás bloqueado"
	echo -e "\033[32mSeleccione el método de verificación:\n\n\033[0m\033[33m\033[01m1、auth_str(por defecto)\n2、obfs\033[0m\033[32m\n\nIngrese una opcion:\033[0m"
	read auth_num
	if [ -z "${auth_num}" ] || [ ${auth_num} == "1" ];then
		auth_type="auth_str"
		auth_str=${auth_secret}
		server_auth_conf=$(cat <<- EOF
"auth": {
"mode": "password",
"config": {
"password": "${auth_str}"
}
},
EOF
)
	else
		auth_type="obfs"
		auth_str=""
		obfs_str=${auth_secret}
		server_auth_conf=$(cat <<- EOF
"obfs": "${obfs_str}",
EOF
)
	fi
	echo -e "\n->El método de verificación que seleccionó es:"`echoColor red ${auth_type}`"\n"
	echoColor green "Por favor ingrese el nombre del cliente (Se utiliza la distinción de nombre de dominio/IP predeterminada,por ejemplo, si ingresa test,el nombre sera Hys-test):"
	read remarks
    echoColor green "\nEntrada de configuración completada!\n"
    echoColor yellowBlack "Ejecutar configuración..."
    download=$(($download + $download / 10))
    upload=$(($upload + $upload / 10))
    r_client=$(($delay * 2 * $download / 1000 * 1024 * 1024))
    r_conn=$(($r_client / 4))
    if echo "${useAcme}" | grep -q "false";then
		if echo "${useLocalCert}" | grep -q "false";then
			v6str=":" #Is ipv6?
			result=$(echo ${ip} | grep ${v6str})
			if [ "${result}" != "" ];then
				ip="[${ip}]" 
			fi
			u_host=${ip}
			u_domain=${domain}
			if [ -z "${remarks}" ];then
				remarks="${ip}"
			fi
			sec="1"
			mail="admin@qq.com"
			days=36500
			echoColor purple "SIGN...\n"
			openssl genrsa -out /etc/hihy/cert/${domain}.ca.key 2048
			openssl req -new -x509 -days ${days} -key /etc/hihy/cert/${domain}.ca.key -subj "/C=CN/ST=GuangDong/L=ShenZhen/O=PonyMa/OU=Tecent/emailAddress=${mail}/CN=Tencent Root CA" -out /etc/hihy/cert/${domain}.ca.crt
			openssl req -newkey rsa:2048 -nodes -keyout /etc/hihy/cert/${domain}.key -subj "/C=CN/ST=GuangDong/L=ShenZhen/O=PonyMa/OU=Tecent/emailAddress=${mail}/CN=Tencent Root CA" -out /etc/hihy/cert/${domain}.csr
			openssl x509 -req -extfile <(printf "subjectAltName=DNS:${domain},DNS:${domain}") -days ${days} -in /etc/hihy/cert/${domain}.csr -CA /etc/hihy/cert/${domain}.ca.crt -CAkey /etc/hihy/cert/${domain}.ca.key -CAcreateserial -out /etc/hihy/cert/${domain}.crt
			rm /etc/hihy/cert/${domain}.ca.key /etc/hihy/cert/${domain}.ca.srl /etc/hihy/cert/${domain}.csr
			mv /etc/hihy/cert/${domain}.ca.crt /etc/hihy/result
			echoColor purple "SUCCESS.\n"
			cat <<EOF > /etc/hihy/result/hihyClient.json
{
"server": "${ip}:${clientPort}",
"protocol": "${protocol}",
"up_mbps": ${upload},
"down_mbps": ${download},
"http": {
"listen": "127.0.0.1:10809",
"timeout" : 300,
"disable_udp": false
},
"socks5": {
"listen": "127.0.0.1:10808",
"timeout": 300,
"disable_udp": false
},
"obfs": "${obfs_str}",
"auth_str": "${auth_str}",
"alpn": "h3",
"acl": "acl/routes.acl",
"mmdb": "acl/Country.mmdb",
"server_name": "${domain}",
"insecure": true,
"recv_window_conn": ${r_conn},
"recv_window": ${r_client},
"disable_mtu_discovery": true,
"resolver": "https://223.5.5.5/dns-query",
"retry": 3,
"retry_interval": 3,
"quit_on_disconnect": false,
"handshake_timeout": 15,
"idle_timeout": 30,
"fast_open": true,
"hop_interval": 120
}
EOF
		else
			u_host=${domain}
			u_domain=${domain}
			if [ -z "${remarks}" ];then
				remarks="${domain}"
			fi
			sec="0"
			cat <<EOF > /etc/hihy/result/hihyClient.json
{
"server": "${domain}:${clientPort}",
"protocol": "${protocol}",
"up_mbps": ${upload},
"down_mbps": ${download},
"http": {
"listen": "127.0.0.1:10809",
"timeout" : 300,
"disable_udp": false
},
"socks5": {
"listen": "127.0.0.1:10808",
"timeout": 300,
"disable_udp": false
},
"obfs": "${obfs_str}",
"alpn": "h3",
"acl": "acl/routes.acl",
"mmdb": "acl/Country.mmdb",
"auth_str": "${auth_str}",
"server_name": "${domain}",
"insecure": false,
"recv_window_conn": ${r_conn},
"recv_window": ${r_client},
"disable_mtu_discovery": true,
"resolver": "https://223.5.5.5/dns-query",
"retry": 3,
"retry_interval": 3,
"quit_on_disconnect": false,
"handshake_timeout": 15,
"idle_timeout": 30,
"fast_open": true,
"hop_interval": 120
}
EOF
		fi		
		cat <<EOF > /etc/hihy/conf/hihyServer.json
{
"listen": ":${port}",
"protocol": "${protocol}",
"disable_udp": false,
"cert": "${cert}",
"key": "${key}",
${server_auth_conf}
"alpn": "h3",
"acl": "/etc/hihy/acl/hihyServer.acl",
"recv_window_conn": ${r_conn},
"recv_window_client": ${r_client},
"max_conn_client": 4096,
"resolve_preference": "46",
"disable_mtu_discovery": true
}
EOF

    else
		u_host=${domain}
		u_domain=${domain}
		sec="0"
		if [ -z "${remarks}" ];then
			remarks="${domain}"
		fi
		getPortBindMsg TCP 80
		allowPort tcp 80
		cat <<EOF > /etc/hihy/conf/hihyServer.json
{
"listen": ":${port}",
"protocol": "${protocol}",
"acme": {
"domains": [
"${domain}"
],
"email": "pekora@${domain}"
},
"disable_udp": false,
${server_auth_conf}
"alpn": "h3",
"acl": "/etc/hihy/acl/hihyServer.acl",
"recv_window_conn": ${r_conn},
"recv_window_client": ${r_client},
"max_conn_client": 4096,
"resolve_preference": "46",
"disable_mtu_discovery": true
}
EOF

		cat <<EOF > /etc/hihy/result/hihyClient.json
{
"server": "${domain}:${clientPort}",
"protocol": "${protocol}",
"up_mbps": ${upload},
"down_mbps": ${download},
"http": {
"listen": "127.0.0.1:10809",
"timeout" : 300,
"disable_udp": false
},
"socks5": {
"listen": "127.0.0.1:10808",
"timeout": 300,
"disable_udp": false
},
"obfs": "${obfs_str}",
"alpn": "h3",
"acl": "acl/routes.acl",
"mmdb": "acl/Country.mmdb",
"auth_str": "${auth_str}",
"server_name": "${domain}",
"insecure": false,
"recv_window_conn": ${r_conn},
"recv_window": ${r_client},
"disable_mtu_discovery": true,
"resolver": "https://223.5.5.5/dns-query",
"retry": 3,
"retry_interval": 3,
"quit_on_disconnect": false,
"handshake_timeout": 15,
"idle_timeout": 30,
"fast_open": true,
"hop_interval": 120
}
EOF
    fi
	sysctl -w net.core.rmem_max=80000000
	if echo "${portHoppingStatus}" | grep -q "true";then
		sysctl -w net.ipv4.ip_forward=1
		sysctl -w net.ipv6.conf.all.forwarding=1
	fi
    sysctl -p
	echo -e "\033[1;;35m\nTest config...\n\033[0m"
	echo "block all udp/443" > /etc/hihy/acl/hihyServer.acl
	/etc/hihy/bin/appS -c /etc/hihy/conf/hihyServer.json server > /tmp/hihy_debug.info 2>&1 &
	sleep 15
	msg=`cat /tmp/hihy_debug.info`
	case ${msg} in 
		*"Failed to get a certificate with ACME"*)
			echoColor red "nombre de dominio:${u_host},¡No se pudo solicitar el certificado! Verifique si el panel de firewall proporcionado por el servidor está activado (TCP:80,443)\n¿El nombre de dominio está resuelto correctamente en esta IP?(¡No abra CDN!)\nSi no puede cumplir con los dos puntos anteriores, reinstálelo y utilice un certificado autofirmado."
			rm /etc/hihy/conf/hihyServer.json
			rm /etc/hihy/result/hihyClient.json
			delHihyFirewallPort
			if echo ${portHoppingStatus} | grep -q "true";then
				delHihyFirewallPort ${portHoppingStart} ${portHoppingEnd} ${port}
			fi
			rm /tmp/hihy_debug.info
			exit
			;;
		*"bind: address already in use"*)
			rm /etc/hihy/conf/hihyServer.json
			rm /etc/hihy/result/hihyClient.json
			delHihyFirewallPort
			if echo ${portHoppingStatus} | grep -q "true";then
				delHihyFirewallPort ${portHoppingStart} ${portHoppingEnd} ${port}
			fi
			echoColor red "El puerto está ocupado, ¡cambie el puerto!"
			rm /tmp/hihy_debug.info
			exit
			;;
		*"Server up and running"*)
			echoColor green "Test success!"
			if [ "${portHoppingStatus}" == "true" ];then
				addPortHoppingNat ${portHoppingStart} ${portHoppingEnd} ${port}
			fi
			allowPort ${ut} ${port}
			echoColor purple "Generating config..."
			if [ "${ut}" == "tcp" ];then
				pIDa=`lsof -i ${ut}:${port} | grep LISTEN | grep -v "PID" | awk '{print $2}'`
			else
				pIDa=`lsof -i ${ut}:${port} | grep -v "PID" | awk '{print $2}'`
			fi
			kill -9 ${pIDa} > /dev/null 2>&1
			rm /tmp/hihy_debug.info
			;;
		*) 	
			if [ "${ut}" == "tcp" ];then
				pIDa=`lsof -i ${ut}:${port} | grep LISTEN | grep -v "PID" | awk '{print $2}'`
			else
				pIDa=`lsof -i ${ut}:${port} | grep -v "PID" | awk '{print $2}'`
			fi
			kill -9 ${pIDa} > /dev/null 2>&1
			rm /etc/hihy/result/hihyClient.json
			delHihyFirewallPort
			if echo ${portHoppingStatus} | grep -q "true";then
				delHihyFirewallPort ${portHoppingStart} ${portHoppingEnd} ${port}
			fi
			echoColor red "Error desconocido: verifique el mensaje de error a continuación y envíe un issue a github"
			cat /tmp/hihy_debug.info
			rm /tmp/hihy_debug.info
			exit
			;;
	esac
	echo "remarks:${remarks}" >> /etc/hihy/conf/hihy.conf
	echo "serverAddress:${u_host}" >> /etc/hihy/conf/hihy.conf
	echo "serverPort:${port}" >> /etc/hihy/conf/hihy.conf
	echo "portHoppingStatus:${portHoppingStatus}" >> /etc/hihy/conf/hihy.conf
	echo "portHoppingStart:${portHoppingStart}" >> /etc/hihy/conf/hihy.conf
	echo "portHoppingEnd:${portHoppingEnd}" >> /etc/hihy/conf/hihy.conf
	if [ $sec = "1" ];then
		skip_cert_verify="true"
	else
		skip_cert_verify="false"
	fi
	if echo ${portHoppingStatus} | grep -q "true";then
		generateMetaYaml "Hys-${remarks}" "${u_host}" "${port}" "${auth_str}" "${protocol}" "${upload}" "${download}" "${u_domain}" "${skip_cert_verify}" "${r_conn}" "${r_client}" "${obfs_str}" "${portHoppingStart}" "${portHoppingEnd}"
		url="hysteria://${u_host}:${port}?mport=${portHoppingStart}-${portHoppingEnd}&protocol=${protocol}&auth=${auth_str}&obfsParam=${obfs_str}&peer=${u_domain}&insecure=${sec}&upmbps=${upload}&downmbps=${download}&alpn=h3#Hys-${remarks}"
	else
		generateMetaYaml "Hys-${remarks}" "${u_host}" "${port}" "${auth_str}" "${protocol}" "${upload}" "${download}" "${u_domain}" "${skip_cert_verify}" "${r_conn}" "${r_client}" "${obfs_str}"
		url="hysteria://${u_host}:${port}?protocol=${protocol}&auth=${auth_str}&obfsParam=${obfs_str}&peer=${u_domain}&insecure=${sec}&upmbps=${upload}&downmbps=${download}&alpn=h3#Hys-${remarks}"
	fi
	echo ${url} > /etc/hihy/result/url.txt
	echoColor greenWhite "La instalación fue exitosa, verifique los detalles de configuración a continuación"
 }

 function downloadHysteriaCore(){
	version=`curl --head -s https://github.com/apernet/hysteria/releases/latest | grep -i location | grep -o 'tag/[^[:space:]]*' | sed 's/tag\///;s/ //g'`
	#Compatible con las actualizaciones de la versión v1 después del lanzamiento de la v2 (temporal, se eliminará en la próxima versión)
	version="v1.3.5"
	echo -e "The Latest hysteria version:"`echoColor red "${version}"`"\nDownload..."
	if [ -z ${version} ];then
		echoColor red "[Network error]: Failed to get the latest version of hysteria in Github!"
		exit
	fi 
    get_arch=`arch`
    if [ $get_arch = "x86_64" ];then
        wget -q -O /etc/hihy/bin/appS --no-check-certificate https://github.com/apernet/hysteria/releases/download/${version}/hysteria-linux-amd64
    elif [ $get_arch = "aarch64" ];then
        wget -q -O /etc/hihy/bin/appS --no-check-certificate https://github.com/apernet/hysteria/releases/download/${version}/hysteria-linux-arm64
    elif [ $get_arch = "mips64" ];then
        wget -q -O /etc/hihy/bin/appS --no-check-certificate https://github.com/apernet/hysteria/releases/download/${version}/hysteria-linux-mipsle
	elif [ $get_arch = "s390x" ];then
		wget -q -O /etc/hihy/bin/appS --no-check-certificate https://github.com/apernet/hysteria/releases/download/${version}/hysteria-linux-s390x
	elif [ $get_arch = "i686" ];then
		wget -q -O /etc/hihy/bin/appS --no-check-certificate https://github.com/apernet/hysteria/releases/download/${version}/hysteria-linux-386
    else
        echoColor yellowBlack "Error[OS Message]:${get_arch}\nPlease open a issue to https://github.com/emptysuns/Hi_Hysteria/issues !"
        exit
    fi
	if [ -f "/etc/hihy/bin/appS" ]; then
		chmod 755 /etc/hihy/bin/appS
		echoColor purple "\nDownload completed."
	else
		echoColor red "Network Error: Can't connect to Github!"
	fi
 }

 function updateHysteriaCore(){
	if [ -f "/etc/hihy/bin/appS" ]; then
		localV=`/etc/hihy/bin/appS -v | cut -d " " -f 3`
		remoteV=`curl --head -s https://github.com/apernet/hysteria/releases/latest | grep -i location | grep -o 'tag/[^[:space:]]*' | sed 's/tag\///;s/ //g'`
		#Compatible con las actualizaciones de la versión v1 después del lanzamiento de la v2 (temporal, se eliminará en la próxima versión)
		remoteV="v1.3.5"
		if [ -z $remoteV ];then
			echoColor red "Network Error: Can't connect to Github!"
			exit
		fi
		echo -e "Local core version:"`echoColor red "${localV}"`
		echo -e "Remote core version:"`echoColor red "${remoteV}"`
		if [ "${localV}" = "${remoteV}" ];then
			echoColor green "Already the latest version.Ignore."
		else
			status=`systemctl is-active hihy`
			if [ "${status}" = "active" ];then #Si se ejecuta normalmente, el Process Daemon se detendrá primero, luego se actualizará automáticamente y luego se reiniciará, de lo contrario, solo será responsable de la actualización.

				systemctl stop hihy
				downloadHysteriaCore
				systemctl start hihy
			else
				downloadHysteriaCore
			fi
			echoColor green "Hysteria Core update done."
		fi
	else
		echoColor red "hysteria core not found."
		exit
	fi
 }



 function changeServerConfig(){
	if [ ! -f "/etc/systemd/system/hihy.service" ]; then
		echoColor red "Instale Hysteria primero y luego modifique la configuración..."
		exit
	fi
	echoColor red "Stop hihy service..."
	systemctl stop hihy
	echoColor red "Delete old config..."
	if [ -f "/etc/hihy/conf/hihy.conf" ]; then
		portHoppingStatus=`cat /etc/hihy/conf/hihy.conf | grep "portHopping" | awk -F ":" '{print $2}'`
		portHoppingStart=`cat /etc/hihy/conf/hihy.conf | grep "portHoppingStart" | awk -F ":" '{print $2}'`
		portHoppingEnd=`cat /etc/hihy/conf/hihy.conf | grep "portHoppingEnd" | awk -F ":" '{print $2}'`
		serverPort=`cat /etc/hihy/conf/hihy.conf | grep "serverPort" | awk -F ":" '{print $2}'`
		msg=`cat /etc/hihy/conf/hihy.conf | grep "remarks"`
		remarks=${msg#*:}
		rm -r /etc/hihy/conf/hihy.conf
		if [ -f "./Hys-${remarks}\(v2rayN\).json" ];then
			rm ./Hys-${remarks}\(v2rayN\).json
		fi
		if [ -f "./Hys-${remarks}\(clashMeta\).yaml" ];then
			rm ./Hys-${remarks}\(clashMeta\).yaml
		fi
		if echo "${portHoppingStatus}" | grep -q "true";then
			delPortHoppingNat ${portHoppingStart} ${portHoppingEnd} ${serverPort}
		fi
	fi
	delHihyFirewallPort
	updateHysteriaCore
	setHysteriaConfig
	systemctl start hihy
	printMsg
	echoColor yellowBlack "Reconfiguración completada."
	
 }

 function hihyUpdate(){
	localV=${hihyV}
	remoteV=`curl -fsSL https://git.io/hysteria.sh | sed  -n 2p | cut -d '"' -f 2`
	if [ -z $remoteV ];then
		echoColor red "Network Error: Can't connect to Github!"
		exit
	fi
	if [ "${localV}" = "${remoteV}" ];then
		echoColor green "Already the latest version.Ignore."
	else
		rm -r /usr/bin/hihy
		wget -q -O /usr/bin/hihy --no-check-certificate https://raw.githubusercontent.com/emptysuns/Hi_Hysteria/main/server/install.sh 2>/dev/null
		chmod +x /usr/bin/hihy
		echoColor green "Done."
	fi

 }

 function hihyNotify(){
	localV=${hihyV}
	remoteV=`curl -fsSL https://git.io/hysteria.sh | sed  -n 2p | cut -d '"' -f 2`
	if [ -z $remoteV ];then
		echoColor red "Network Error: Can't connect to Github for checking hihy version!"
	else
		if [ "${localV}" != "${remoteV}" ];then
			echoColor purple "[Update] hihy tiene una actualizacion,version:v${remoteV},Sugerir actualizaciones y consultar los registros: https://github.com/emptysuns/Hi_Hysteria/commits/main"
		fi
	fi
	

 }

 function hyCoreNotify(){
	if [ -f "/etc/hihy/bin/appS" ]; then
  		localV=`/etc/hihy/bin/appS -v | cut -d " " -f 3`
		remoteV=`curl --head -s https://github.com/apernet/hysteria/releases/latest | grep -i location | grep -o 'tag/[^[:space:]]*' | sed 's/tag\///;s/ //g'`
		#Compatible con las actualizaciones de la versión v1 después del lanzamiento de la v2 (temporal, se eliminará en la próxima versión)
		remoteV="v1.3.5"
		if [ -z $remoteV ];then
			echoColor red "Network Error: Can't connect to Github for checking the hysteria version!"
		else
			if [ "${localV}" != "${remoteV}" ];then
				echoColor purple "[Update] Hysteria tiene una actualizacion,version:${remoteV}. registro: https://github.com/apernet/hysteria/blob/master/CHANGELOG.md"
			fi
		fi
		
	fi
 }


 function checkStatus(){
	status=`systemctl is-active hihy`
    if [ "${status}" = "active" ];then
		echoColor green "Hysteria funciona normalmente"
	else
		echoColor red "Dead! Hysteria NO funciona correctamente"
	fi
 }

 function install()
 {	
	if [ -f "/etc/systemd/system/hihy.service" ]; then
		echoColor green "Has instalado con éxito Hysteria. Si necesita modificar la configuración, utilice la opción 9/12"
		exit
	fi
	mkdir -p /etc/hihy/bin /etc/hihy/conf /etc/hihy/cert  /etc/hihy/result
    echoColor purple "Ready to install.\n"
    version=`curl --head -s https://github.com/apernet/hysteria/releases/latest | grep -i location | grep -o 'tag/[^[:space:]]*' | sed 's/tag\///;s/ //g'`
    #兼容v2发布后的v1版本更新（暂时性的，下个版本移除）
	version="v1.3.5"
	checkSystemForUpdate
	downloadHysteriaCore
	setHysteriaConfig
    cat <<EOF >/etc/systemd/system/hihy.service
[Unit]
Description=hysteria:Hello World!
After=network.target

[Service]
Type=simple
PIDFile=/run/hihy.pid
ExecStart=/etc/hihy/bin/appS --log-level info -c /etc/hihy/conf/hihyServer.json server
#Restart=on-failure
#RestartSec=10s

[Install]
WantedBy=multi-user.target
EOF
    chmod 644 /etc/systemd/system/hihy.service
    systemctl daemon-reload
    systemctl enable hihy
    systemctl start hihy
	crontab -l > /tmp/crontab.tmp
	echo  "15 4 * * 1,4 hihy cronTask" >> /tmp/crontab.tmp
	crontab /tmp/crontab.tmp
	rm /tmp/crontab.tmp
	printMsg
	echoColor yellowBlack "Instalado"
 }


 # Status de salida del puerto abierto UFW
 function checkUFWAllowPort() {
	if ufw status | grep -q "$1"; then
		echoColor purple "UFW OPEN: ${1}"
	else
		echoColor red "UFW OPEN FAIL: ${1}"
		exit 0
	fi
 }

 # 输出firewall-cmd端口开放状态
 function checkFirewalldAllowPort() {
	if firewall-cmd --list-ports --permanent | grep -q "$1"; then
		echoColor purple "FIREWALLD OPEN: ${1}/${2}"
	else
		echoColor red "FIREWALLD OPEN FAIL: ${1}/${2}"
		exit 0
	fi
 }

 function allowPort() {
	# 如果防火墙启动状态则添加相应的开放端口
	# $1 tcp/udp
	# $2 port
	if systemctl status netfilter-persistent 2>/dev/null | grep -q "active (exited)"; then
		local updateFirewalldStatus=
		if ! iptables -L | grep -q "allow ${1}/${2}(hihysteria)"; then
			updateFirewalldStatus=true
			iptables -I INPUT -p ${1} --dport ${2} -m comment --comment "allow ${1}/${2}(hihysteria)" -j ACCEPT 2> /dev/null
			echoColor purple "IPTABLES OPEN: ${1}/${2}"
		fi
		if echo "${updateFirewalldStatus}" | grep -q "true"; then
			netfilter-persistent save 2>/dev/null
		fi
	elif [[ `ufw status 2>/dev/null | grep "Status: " | awk '{print $2}'` = "active" ]]; then
		if ! ufw status | grep -q ${2}; then
			ufw allow ${2} 2>/dev/null
			checkUFWAllowPort ${2}
		fi
	elif systemctl status firewalld 2>/dev/null | grep -q "active (running)"; then
		local updateFirewalldStatus=
		if ! firewall-cmd --list-ports --permanent | grep -qw "${2}/${1}"; then
			updateFirewalldStatus=true
			firewall-cmd --zone=public --add-port=${2}/${1} --permanent 2>/dev/null
			checkFirewalldAllowPort ${2} ${1}
		fi
		if echo "${updateFirewalldStatus}" | grep -q "true"; then
			firewall-cmd --reload
		fi
	fi
 }

 function delPortHoppingNat(){
	# $1 portHoppingStart
	# $2 portHoppingEnd
	# $3 portHoppingTarget
	if systemctl status firewalld 2>/dev/null | grep -q "active (running)"; then
		firewall-cmd --permanent --remove-forward-port=port=$1-$2:proto=udp:toport=$3
		firewall-cmd --reload
	else
		iptables -t nat -F PREROUTING  2>/dev/null
		ip6tables -t nat -F PREROUTING  2>/dev/null
		if systemctl status netfilter-persistent 2>/dev/null | grep -q "active (exited)"; then
			netfilter-persistent save 2> /dev/null
		fi

	fi
 }

 function addPortHoppingNat() {
	# $1 portHoppingStart
	# $2 portHoppingEnd
	# $3 portHoppingTarget
	# 如果防火墙启动状态则删除之前的规则
	if [[ -n $(find /etc -name "redhat-release") ]] || grep </proc/version -q -i "centos"; then
		mkdir -p /etc/yum.repos.d

		if [[ -f "/etc/centos-release" ]]; then
			centosVersion=$(rpm -q centos-release | awk -F "[-]" '{print $3}' | awk -F "[.]" '{print $1}')

			if [[ -z "${centosVersion}" ]] && grep </etc/centos-release -q -i "release 8"; then
				centosVersion=8
			fi
		fi
		release="centos"
		installType='yum -y -q install'
		removeType='yum -y -q remove'
		upgrade="yum update -y  --skip-broken"
	elif grep </etc/issue -q -i "debian" && [[ -f "/etc/issue" ]] || grep </etc/issue -q -i "debian" && [[ -f "/proc/version" ]]; then
		release="debian"
		installType='apt -y -q install'
		upgrade="apt update"
		updateReleaseInfoChange='apt-get --allow-releaseinfo-change update'
		removeType='apt -y -q autoremove'
	elif grep </etc/issue -q -i "ubuntu" && [[ -f "/etc/issue" ]] || grep </etc/issue -q -i "ubuntu" && [[ -f "/proc/version" ]]; then
		release="ubuntu"
		installType='apt -y -q install'
		upgrade="apt update"
		updateReleaseInfoChange='apt-get --allow-releaseinfo-change update'
		removeType='apt -y -q autoremove'
		if grep </etc/issue -q -i "16."; then
			release=
		fi
	fi

	if [[ -z ${release} ]]; then
		echoColor red "\nEste script no es compatible con este sistema. Envíe el siguiente registro al desarrollador\n"
		echoColor yellow "$(cat /etc/issue)"
		echoColor yellow "$(cat /proc/version)"
		exit 0
	fi

	if systemctl status firewalld 2>/dev/null | grep -q "active (running)"; then
		if ! firewall-cmd --query-masquerade --permanent 2>/dev/null | grep -q "yes"; then
			firewall-cmd --add-masquerade --permanent 2>/dev/null
			firewall-cmd --reload 2>/dev/null
			echoColor purple "FIREWALLD MASQUERADE OPEN"
		fi
		firewall-cmd --add-forward-port=port=$1-$2:proto=udp:toport=$3 --permanent 2>/dev/null
		firewall-cmd --reload 2>/dev/null
	else
		if ! [ -x "$(command -v netfilter-persistent)" ]; then
			echoColor green "*iptables-persistent"
			echoColor purple "\nUpdate.wait..."
			${upgrade}
			${installType} "iptables-persistent"
		fi
		if ! [ -x "$(command -v netfilter-persistent)" ]; then
			echoColor red "[Advertencia]: la instalacion de netfilter-persistent fallo,pero el progreso de la instalacion no se detendra,Es solo que sus reglas de reenvío PortHopping son temporales,el reinicio puede fallar,deberia continuar usando reglas temporales?(y/N)"
			read continueInstall
			if [[ "${continueInstall}" != "y" ]]; then
				exit 0
			fi
		fi
		iptables -t nat -F PREROUTING  2>/dev/null
		iptables -t nat -A PREROUTING -p udp --dport $1:$2 -m comment --comment "NAT $1:$2 to $3 (PortHopping-hihysteria)" -j DNAT --to-destination :$3 2>/dev/null
		ip6tables -t nat -A PREROUTING -p udp --dport $1:$2 -m comment --comment "NAT $1:$2 to $3 (PortHopping-hihysteria)" -j DNAT --to-destination :$3 2>/dev/null
		
		if systemctl status netfilter-persistent 2>/dev/null | grep -q "active (exited)"; then
			netfilter-persistent save 2> /dev/null
		else 
			echoColor red "netfilter-persistent no se ha iniciado,Las reglas de reenvío PortHopping no se pueden conservar,El reinicio del sistema fallará,ejecute manualmente el guardado de netfilter-persistent save,Continuar ejecutando el script no afectará las configuraciones posteriores..."
		fi

	fi
    
 }

 function delHihyFirewallPort() {
	# 如果防火墙启动状态则删除之前的规则
	port=`cat /etc/hihy/conf/hihyServer.json | grep "listen" | awk '{print $2}' | tr -cd "[0-9]"`
	if [[ `ufw status 2>/dev/null | grep "Status: " | awk '{print $2}'` = "active" ]]	; then
		if ufw status | grep -q ${port}; then
			sudo ufw delete allow ${port} 2> /dev/null
		fi
	elif systemctl status firewalld 2>/dev/null | grep -q "active (running)"; then
		local updateFirewalldStatus=
		isFaketcp=`cat /etc/hihy/conf/hihyServer.json | grep "faketcp"`
		if [ -z "${isFaketcp}" ];then
			ut="udp"
		else
			ut="tcp"
		fi
		if firewall-cmd --list-ports --permanent | grep -qw "${port}/${ut}"; then
			updateFirewalldStatus=true
			firewall-cmd --zone=public --remove-port=${port}/${ut} --permanent 2> /dev/null
		fi
		if echo "${updateFirewalldStatus}" | grep -q "true"; then
			firewall-cmd --reload 2> /dev/null
		fi
	elif systemctl status netfilter-persistent 2>/dev/null | grep -q "active (exited)"; then
		updateFirewalldStatus=true
		iptables-save |  sed -e '/hihysteria/d' | iptables-restore
		if echo "${updateFirewalldStatus}" | grep -q "true"; then
			netfilter-persistent save 2>/dev/null
		fi
	fi
 }

function checkRoot(){
	user=`whoami`
	if [ ! "${user}" = "root" ];then
		echoColor red "Please run as root user!"
		exit 0
	fi
}

 function editProtocol(){
	# $1 change to $2, example(editProtocol 'udp' 'faketcp'): udp to faketcp
	portHoppingStatus=`cat /etc/hihy/conf/hihy.conf | grep "portHopping" | awk -F ":" '{print $2}'`
	portHoppingStart=`cat /etc/hihy/conf/hihy.conf | grep "portHoppingStart" | awk -F ":" '{print $2}'`
	portHoppingEnd=`cat /etc/hihy/conf/hihy.conf | grep "portHoppingEnd" | awk -F ":" '{print $2}'`
	serverPort=`cat /etc/hihy/conf/hihy.conf | grep "serverPort" | awk -F ":" '{print $2}'`
	sed -i "s/\"protocol\": \"${1}\"/\"protocol\": \"${2}\"/g" /etc/hihy/conf/hihyServer.json
	sed -i "s/\"protocol\": \"${1}\"/\"protocol\": \"${2}\"/g" /etc/hihy/result/hihyClient.json
	sed -i "s/protocol: ${1}/protocol: ${2}/g" /etc/hihy/result/metaHys.yaml
	sed -i "s/protocol=${1}/protocol=${2}/g" /etc/hihy/result/url.txt
	if echo "${portHoppingStatus}" | grep -q "true";then
		msg=`cat /etc/hihy/conf/hihy.conf | grep "serverAddress"`
		serverAddress=${msg#*:}
		delPortHoppingNat ${portHoppingStart} ${portHoppingEnd} ${serverPort}
		msg=`cat /etc/hihy/result/hihyClient.json | grep \"server\" | awk '{print $2}' | awk '{split($1, arr, ":"); print arr[2]}'`
		port_before=${msg::length-2}
		port_after=${msg%%,*}
		sed -i "s/\"server\": \"${serverAddress}:${port_before}\"/\"server\": \"${serverAddress}:${port_after}\"/g" /etc/hihy/result/hihyClient.json
		sed -i "s/mport=${portHoppingStart}-${portHoppingEnd}&//g" /etc/hihy/result/url.txt
		sed -i "s/\portHoppingStatus:true/portHoppingStatus:false/g" /etc/hihy/conf/hihy.conf
	fi
 }

 function changeMode(){
	if [ ! -f "/etc/hihy/conf/hihyServer.json" ]; then
		echoColor red "El archivo de configuración no existe, saliendo..."
		exit
	fi
	protocol=`cat /etc/hihy/conf/hihyServer.json  | grep protocol | awk '{print $2}' | awk -F '"' '{ print $2}'`
	echoColor yellow "El protocolo actual es:"
	echoColor purple "${protocol}"
	port=`cat /etc/hihy/conf/hihyServer.json | grep "listen" | awk '{print $2}' | tr -cd "[0-9]"`
	if [ "${protocol}" = "udp" ];then
		echo -e "\033[32m\nPor favor seleccione el tipo de protocolo a modificar:\n\n\033[0m\033[33m\033[01m1、faketcp\n2、wechat-video\033[0m\033[32m\n\nIngrese una opcion:\033[0m"
    	read pNum
		if [ -z "${pNum}" ] || [ "${pNum}" == "1" ];then
			echoColor purple "Seleccione para modificar el tipo de protocolo a faketcp."
			editProtocol "udp" "faketcp"
			delHihyFirewallPort
			allowPort "tcp" ${port}
		else
			echoColor purple "Seleccione para modificar el tipo de protocolo a wechat-video."
			editProtocol "udp" "wechat-video"
		fi
	elif [ "${protocol}" = "faketcp" ];then
		delHihyFirewallPort
		allowPort "udp" ${port}
		echo -e "\033[32m\nPor favor seleccione el tipo de protocolo a modificar:\n\n\033[0m\033[33m\033[01m1、udp\n2、wechat-video\033[0m\033[32m\n\nIngrese una opcion:\033[0m"
    	read pNum
		if [ -z "${pNum}" ] || [ "${pNum}" == "1" ];then
			echoColor purple "Elija modificar el tipo de protocolo a UDP."
			editProtocol "faketcp" "udp"
		else
			echoColor purple "Seleccione para modificar el tipo de protocolo a wechat-video."
			editProtocol "faketcp" "wechat-video"
		fi
	elif [ "${protocol}" = "wechat-video" ];then
		echo -e "\033[32m\nPor favor seleccione el tipo de protocolo a modificar:\n\n\033[0m\033[33m\033[01m1、udp\n2、faketcp\033[0m\033[32m\n\nIngrese una opcion:\033[0m"
    	read pNum
		if [ -z "${pNum}" ] || [[ "${pNum}" == "1" ]];then
			echoColor purple "Elija modificar el tipo de protocolo a UDP."
			editProtocol wechat-video udp
		else
			delHihyFirewallPort
			allowPort "tcp" ${port}
			echoColor purple "Seleccione para modificar el tipo de protocolo a faketcp."
			editProtocol "wechat-video" "faketcp"
		fi
	else
		echoColor red "¡No se puede reconocer el tipo de protocolo!"
		exit
	fi
	systemctl restart hihy
	echoColor green "Modificado con éxito"
 }


 function generateMetaYaml(){
	if [[ ${4} == "" ]];then
		clashClient_auth_conf=$(cat <<- EOF
	obfs: ${12}
EOF
)
	else
		clashClient_auth_conf=$(cat <<- EOF
	auth_str: ${4}
EOF
)
	fi

	if [[ ${13} == "" ]];then
		port_conf=$(cat <<- EOF
	port: ${3}
EOF
)
	else
		port_conf=$(cat <<- EOF
	ports: ${13}-${14}
EOF
)
	fi

	cat <<EOF > /etc/hihy/result/metaHys.yaml
mixed-port: 7890
allow-lan: true
mode: rule
log-level: info
ipv6: true
dns:
  enable: true
  listen: 0.0.0.0:53
  ipv6: true
  default-nameserver:
    - 114.114.114.114
    - 223.5.5.5
  enhanced-mode: redir-host
  nameserver:
    - https://dns.alidns.com/dns-query
    - https://223.5.5.5/dns-query
  fallback:
    - 114.114.114.114
    - 223.5.5.5

proxies:
  - name: "$1"
    type: hysteria
    server: ${2}
    ${port_conf}
    ${clashClient_auth_conf}
    alpn:
      - h3
    protocol: ${5}
    up: ${6}
    down: ${7}
    sni: ${8}
    skip-cert-verify: ${9}
    recv_window_conn: ${10}
    recv_window: ${11}
    disable_mtu_discovery: true
    fast-open: true
proxy-groups:
  - name: "PROXY"
    type: select
    proxies:
     - $1

rule-providers:
  reject:
    type: http
    behavior: domain
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/reject.txt"
    path: ./ruleset/reject.yaml
    interval: 86400

  icloud:
    type: http
    behavior: domain
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/icloud.txt"
    path: ./ruleset/icloud.yaml
    interval: 86400

  apple:
    type: http
    behavior: domain
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/apple.txt"
    path: ./ruleset/apple.yaml
    interval: 86400

  google:
    type: http
    behavior: domain
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/google.txt"
    path: ./ruleset/google.yaml
    interval: 86400

  proxy:
    type: http
    behavior: domain
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/proxy.txt"
    path: ./ruleset/proxy.yaml
    interval: 86400

  direct:
    type: http
    behavior: domain
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/direct.txt"
    path: ./ruleset/direct.yaml
    interval: 86400

  private:
    type: http
    behavior: domain
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/private.txt"
    path: ./ruleset/private.yaml
    interval: 86400

  gfw:
    type: http
    behavior: domain
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/gfw.txt"
    path: ./ruleset/gfw.yaml
    interval: 86400

  greatfire:
    type: http
    behavior: domain
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/greatfire.txt"
    path: ./ruleset/greatfire.yaml
    interval: 86400

  tld-not-cn:
    type: http
    behavior: domain
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/tld-not-cn.txt"
    path: ./ruleset/tld-not-cn.yaml
    interval: 86400

  telegramcidr:
    type: http
    behavior: ipcidr
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/telegramcidr.txt"
    path: ./ruleset/telegramcidr.yaml
    interval: 86400

  cncidr:
    type: http
    behavior: ipcidr
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/cncidr.txt"
    path: ./ruleset/cncidr.yaml
    interval: 86400

  lancidr:
    type: http
    behavior: ipcidr
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/lancidr.txt"
    path: ./ruleset/lancidr.yaml
    interval: 86400

  applications:
    type: http
    behavior: classical
    url: "https://ghproxy.com/https://raw.githubusercontent.com/Loyalsoldier/clash-rules/release/applications.txt"
    path: ./ruleset/applications.yaml
    interval: 86400

rules:
  - RULE-SET,applications,DIRECT
  - DOMAIN,clash.razord.top,DIRECT
  - DOMAIN,yacd.haishan.me,DIRECT
  - DOMAIN,services.googleapis.cn,PROXY
  - RULE-SET,private,DIRECT
  - RULE-SET,reject,REJECT
  - RULE-SET,icloud,DIRECT
  - RULE-SET,apple,DIRECT
  - RULE-SET,google,DIRECT
  - RULE-SET,proxy,PROXY
  - RULE-SET,direct,DIRECT
  - RULE-SET,lancidr,DIRECT
  - RULE-SET,cncidr,DIRECT
  - RULE-SET,telegramcidr,PROXY
  - GEOIP,LAN,DIRECT
  - GEOIP,CN,DIRECT
  - MATCH,PROXY
EOF
 }

 function checkLogs(){
	echoColor purple "registro de Hysteria en tiempo real,nivel:info,presione Ctrl+C para salir:"
	journalctl -u hihy --output cat -f
 }

 function cronTask(){
	systemctl restart hihy #防止hysteria占用内存过大
	systemctl restart systemd-journald #防止日志占用内存过大
 }

 function start(){
	systemctl start hihy
	echoColor purple "start..."
	sleep 5
	status=`systemctl is-active hihy`
	if [ "${status}" = "active" ];then
		echoColor green "Comenzó con éxito"
	else
		echoColor red "El inicio falló"
		echo -e "Error desconocido: ejecute manualmente:\033[32m/etc/hihy/bin/appS -c /etc/hihy/conf/hihyServer.json server\033[0m"
		echoColor red "¡Consulte el registro de errores y envíe comentarios sobre el problema!"
	fi
 }

 function stop(){
	systemctl stop hihy
	echoColor green "Suspendido con éxito"
 }

 function restart(){
	systemctl restart hihy
	echoColor purple "restart..."
	sleep 5
	status=`systemctl is-active hihy`
	if [ "${status}" = "active" ];then
		echoColor green "Reinicio exitosamente"
	else
		echoColor red "Reinicio fallido"
		echo -e "Error desconocido: ejecute manualmente:\033[32m/etc/hihy/bin/appS -c /etc/hihy/conf/hihyServer.json server\033[0m"
		echoColor red "¡Consulte el registro de errores y envíe comentarios sobre el problema!"
	fi
 }

 function menu()
 {
hihy
clear
cat << EOF
 -------------------------------------------
|**********      Hi Hysteria       **********|
|******** Traducido por Emir Jorge **********|
|**********    Author: emptysuns   **********|
|**********     Version: `echoColor red "${hihyV}"`    **********|
 -------------------------------------------
Tips:`echoColor green "hihy"`comando para ejecutar este script.
`echoColor skyBlue "............................................."`
`echoColor purple "###############################"`

`echoColor skyBlue "....................."`
`echoColor yellow "1)  Instalar Hysteria"`
`echoColor magenta "2)  Desinstalar"`
`echoColor skyBlue "....................."`
`echoColor yellow "3)  Iniciar"`
`echoColor magenta "4)  Pausar"`
`echoColor yellow "5)  Reanudar"`
`echoColor yellow "6)  Estado de Hysteria"`
`echoColor skyBlue "....................."`
`echoColor yellow "7)  Actualizar Core"`
`echoColor yellow "8)  Ver configuración actual"`
`echoColor skyBlue "9)  Reconfigurar"`
`echoColor yellow "10) Cambiar prioridad ipv4/ipv6"`
`echoColor yellow "11) Actualizar hihy"`
`echoColor red "12) Restablecer todas las configuraciones"`
`echoColor skyBlue "13) Modificar el tipo de protocolo actual"`
`echoColor yellow "14) Ver registros en tiempo real"`

`echoColor purple "###############################"`
`hihyNotify`
`hyCoreNotify`

`echoColor magenta "0) Salir"`
`echoColor skyBlue "............................................."`
EOF
read -p "Por favor elige:" input
case $input in
	1)	
		install
	;;
	2)
		uninstall
	;;
	3)
		start
	;;
	4)
		stop
	;;
    5)
        restart
    ;;
    6)
        checkStatus
	;;
	7)
		updateHysteriaCore
	;;
	8)
		printMsg
    ;;
    9)
        changeServerConfig
    ;;
	10)
        changeIp64
    ;;
	11)
        hihyUpdate
		
    ;;
	12)
        reinstall
	;;
	13)
        changeMode
	;;
	14)
		checkLogs
    ;;
	0)
		exit 0
	;;
	*)
		echoColor red "Input Error !!!"
		exit 1
	;;
    esac
 }

 checkRoot
 if [ "$1" == "install" ] || [ "$1" == "1" ]; then
 	echoColor purple "-> 1) Instalar Hysteria"
 	install
 elif [ "$1" == "uninstall" ] || [ "$1" == "2" ]; then
 	echoColor purple "-> 2) Desinstalar Hysteria"
 	uninstall
 elif [ "$1" == "start" ]  || [ "$1" == "3"  ]; then
 	echoColor purple "-> 3) Iniciar Hysteria"
 	start
 elif [ "$1" == "stop" ]  || [ "$1" == "4" ]; then
 	echoColor purple "-> 4) Detener Hysteria"
 	stop
 elif [ "$1" == "restart" ]  || [ "$1" == "5" ]; then
 	echoColor purple "-> 5) Reiniciar Hysteria"
 	restart
 elif [ "$1" == "checkStatus" ]  || [ "$1" == "6" ]; then
 	echoColor purple "-> 6) Estado de Hysteria"
 	checkStatus
 elif [ "$1" == "updateHysteriaCore" ]  || [ "$1" == "7" ]; then
 	echoColor purple "-> 7) Actualizar Core"
 	updateHysteriaCore
 elif [ "$1" == "printMsg" ]  || [ "$1" == "8" ]; then
 	echoColor purple "-> 8) Ver config actual"
 	printMsg
 elif [ "$1" == "changeServerConfig" ]  || [ "$1" == "9" ]; then
 	echoColor purple "-> 9) Reconfigurar"
 	changeServerConfig
 elif [ "$1" == "changeIp64" ]  || [ "$1" == "10" ]; then
 	echoColor purple "-> 10) Cambiar prioridad ipv4/ipv6"
 	changeIp64
 elif [ "$1" == "hihyUpdate" ]  || [ "$1" == "11" ]; then
 	echoColor purple "-> 11) Actualizar hihy"
 	hihyUpdate
 elif [ "$1" == "reinstall" ]  || [ "$1" == "12" ]; then
 	echoColor purple "-> 12) Restablecer todas las configuraciones"
 	reinstall
 elif [ "$1" == "changeMode" ]  || [ "$1" == "13" ]; then
 	echoColor purple "-> 13) Modificar el tipo de protocolo actual"
 	changeMode
 elif [ "$1" == "checkLogs" ]  || [ "$1" == "14" ]; then
 	echoColor purple "-> 14) Ver registros en tiempo real"
 	checkLogs
 elif [ "$1" == "cronTask" ]; then
 	cronTask
 else
 	menu
 fi
