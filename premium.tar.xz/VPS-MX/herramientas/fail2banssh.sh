#!/bin/bash
clear
clear
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )
pid_fail=$(dpkg -l | grep fail2ban | grep ii)
msg -tit
echo -e "\e[93m            Fail2ban Protection para SSH"
echo -e "\e[97m          Anti ataques DDOS y spoofing SPAM"
msg -bar
if [[ ! -z "$pid_fail" ]]; then
    echo -e "${cor[2]} [1] >${cor[5]} $(fun_trans "Desinstalar Fail2ban")"
    echo -e "${cor[2]} [2] >\e[92m $(fun_trans "Ver el registro")"
    msg -bar
    while [[ -z ${opcionx} || ${opcionx} != @(1|2) ]]; do
        echo -ne "\033[1;37m$(fun_trans "Seleccione una Opcion"): " && read opcionx
        tput cuu1 && tput dl1
    done
    case ${opcionx} in
        1) apt-get remove fail2ban -y &> /dev/null;;
        2) cat /var/log/fail2ban.log 
        msg -bar;;
    esac
exit 0
fi
echo -e "${cor[0]}               ¿Desea Instalar  Fail2ban?"
msg -bar

while [[ -z ${fail2ban} || ${fail2ban} != @(s|S|n|N|y|Y) ]]; do
    echo -ne "\033[1;37m$(fun_trans " Seleccione una Opcion") [S/N]: " && read fail2ban
    tput cuu1 && tput dl1
   done
if [[ "$fail2ban" = @(s|S|y|Y) ]]; then

apt install fail2ban -y
#######
echo -ne "\e[1;97m Establezca tiempo de Baneo en Hrs\e[1;91m [Ejemplo 24]: \e[0m"
read tiempo
if [[ -z $tiempo ]]; then
tiempo="24"
echo -e " Tiempo predeterminado: ${tiempo} Horas "
else
echo -e " Tiempo configurado en: ${tiempo} Horas "
fi
echo ""
#######
echo -ne "\e[1;97m Establezca el Nº intentos fallidos \e[1;91m[Ejemplo 3]: \e[0m"
read intentos
if [[ -z $intentos ]]; then
intentos="3"
echo -e " Predeterminado: ${intentos} Intentos "
else
echo -e " Nº de Intentos: ${intentos} "
fi
echo ""
#######
echo -ne "\e[1;97m Rango/Tiempo de intentos fallidos \e[1;91m[minutos 10]: \e[0m"
read rango_tiempo
if [[ -z $rango_tiempo ]]; then
rango_tiempo="10"
echo -e " Predeterminado: ${rango_tiempo} Minutos "
else
echo -e " Tiempo en minutos entre intentos de login: ${rango_tiempo} "
fi
echo ""
systemctl enable fail2ban.service
echo -e "[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = $intentos
bantime = ${tiempo}h
findtime = ${rango_tiempo}m
ignoreip = 127.0.0.1" > /etc/fail2ban/jail.local
systemctl restart fail2ban.service
fi
