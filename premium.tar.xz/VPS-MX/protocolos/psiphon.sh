 #!/bin/bash
 # 15/09/2023 by @Emir Jorge
 clear 
 clear
 instalador_psiphon1() {
    clear
    if ps aux | grep 'psiphond' | grep -v grep >/dev/null; then echo -e "El proceso psiphond ya está activo." exit 1; fi

    msg -bar
    msg -tit
    
    msg -ama "            INSTALADOR PSIPHON SERVER"
    msg -bar
    echo -e "\033[1;97m Ingrese los puertos segun su necesidad\033[1;97m\n"
    
    rm -rf /root/psi
    kill $(ps aux | grep 'psiphond' | awk '{print $2}') 1>/dev/null 2>/dev/null
    killall psiphond 1>/dev/null 2>/dev/null
    cd /root
    mkdir psi
    cd /root/psi
    myip=$(wget -qO- ifconfig.me/ip)
    curl -o /root/psi/psiphond https://raw.githubusercontent.com/Psiphon-Labs/psiphon-tunnel-core-binaries/master/psiphond/psiphond 1>/dev/null 2>/dev/null
    chmod 777 psiphond
    echo -ne "\033[1;97m Escribe el puerto para Psiphon SSH:\033[32m " && read -p " " -e -i "23" sh
    echo -ne "\033[1;97m Escribe el puerto para Psiphon OSSH:\033[32m " && read osh
    echo -ne "\033[1;97m Escribe el puerto para Psiphon FRONTED-MEEK-OSSH:\033[32m " && read fm
    echo -ne "\033[1;97m Escribe el puerto para Psiphon UNFRONTED-MEEK-OSSH:\033[32m " && read umo
  #  echo -e "$sh\n$osh\n$fm\n$umo" > /root/psi/ports.txt
    ./psiphond --ipaddress $myip --protocol SSH:$sh --protocol OSSH:$osh --protocol FRONTED-MEEK-OSSH:$fm --protocol UNFRONTED-MEEK-OSSH:$umo generate
    chmod 666 psiphond.config
    chmod 666 psiphond-traffic-rules.config
    chmod 666 psiphond-osl.config
    chmod 666 psiphond-tactics.config
    chmod 666 server-entry.dat
     
    
cat server-entry.dat >/root/psi/psi.txt
    #screen -dmS psiserver ./psiphond run
    cat <<EOF > /etc/systemd/system/psiserver.service
[Unit]
Description=psiserver by lacasitamx

[Service]
User=root
Type=simple
ExecStart=/root/psi/psiphond run
WorkingDirectory=/root/psi/
Restart=always
RestartSec=2s

[Install]
WantedBy=default.target
EOF

systemctl enable psiserver &>/dev/null
systemctl start psiserver &>/dev/null

    cd /root
    psi=$(cat /root/psi/psi.txt)
    echo -e "\033[1;33m LA CONFIGURACION DE TU SERVIDOR ES:\033[0m"
    msg -bar
    echo -e "\033[1;32m $psi \033[0m"
    msg -bar
    echo -e "\033[1;97m PROTOCOLOS HABILITADOS:\033[0m"
    msg -bar
    echo -e "\033[1;33m → SSH:\033[1;32m $sh \033[0m"
    echo -e "\033[1;33m → OSSH:\033[1;32m $osh \033[0m"
    echo -e "\033[1;33m → FRONTED-MEEK-OSSH:\033[1;32m $fm \033[0m"
    echo -e "\033[1;33m → UNFRONTED-MEEK-OSSH:\033[1;32m $umo \033[0m"
    msg -bar
    echo -e "\033[93m DIRECTORIO DE ARCHIVOS:\033[1;32m /root/psi \033[0m"
    msg -bar
    [[ "$(ps aux | grep psiphond | grep -v grep)" ]] && msg -verd "    >> SERVIDOR-PSIPHON INSTALADO CON EXITO <<" || msg -ama "                  ERROR VERIFIQUE"
    msg -bar
    #msg -ne "Enter Para Continuar" && read enter
   }
 desactivar_psiphon() {
    clear 
    msg -bar
    echo -e "\033[1;31m            DESISNTALANDO PUERTOS PSIPHON-SERVER "
    msg -bar
    systemctl stop psiserver &>/dev/null
    systemctl disable psiserver &>/dev/null
    rm -rf /etc/systemd/system/psiserver.service
    rm -rf /root/psi
    rm -rf /root/psi/psi.txt
    rm /bin/psiphond &>/dev/null
    #rm /var/www/html/psi.txt &>/dev/null
    #[[ "$(ps aux | grep psiphond | grep -v grep)" ]] && echo -e "\033[1;32m        >> PSIPHON-SERVER DESINSTALADO CON EXITO << "
    [[ ! "$(ps aux | grep psiphond | grep -v grep)" ]] && echo -e "\033[1;32m        >> PSIPHON-SERVER DESINSTALADO CON EXITO << "
    echo -e " "
    #msg -ne "Enter Para Continuar" && read enter
 }
  
 clear
  [[ $(ps x | grep psiphond| grep -v grep) ]] && psh="\033[1;32m[ACTIVO]" || psh="\033[1;31m[OFF]"
 
  #msg -bar6
  msg -tit

  msg -ama "            INSTALADOR DE PSIPHON CUSTOM"
  msg -bar | lolcat
  if [[ ! -e /bin/psiphond ]]; then
    curl -o /bin/psiphond https://raw.githubusercontent.com/Psiphon-Labs/psiphon-tunnel-core-binaries/master/psiphond/psiphond &>/dev/null
    chmod 777 /bin/psiphond
  fi
  echo -ne " \e[1;93m [\e[1;32m1\e[1;93m]\033[1;31m > \e[1;97m INSTALAR PSIPHON \n"
  echo -ne " \e[1;93m [\e[1;32m2\e[1;93m]\033[1;31m > \033[1;91m DETENER SERVICIO PSIPHON \n"
  echo -ne " \e[1;93m [\e[1;32m3\e[1;93m]\033[1;31m > \033[1;92m CONFIG SERVER-ENTRY.DAT \n"
  
  msg -bar
  echo -ne " \e[1;93m [\e[1;32m0\e[1;93m]\033[1;31m > \033[1;97m" && msg -bra "  \e[97m\033[1;41m VOLVER \033[1;37m"
  msg -bar
  echo -ne "  \033[1;97mDigite una opcion:\e[32m "
  read opcao
  case $opcao in
  1)
    msg -bar
    instalador_psiphon1
    ;;
  2)
    msg -bar
    desactivar_psiphon
    ;;
  3)
    clear
    echo -e "\e[97m $(cat /root/psi/psi.txt)"
    msg -bar
    #echo -e "\033[1;97m PROTOCOLOS HABILITADOS:\033[0m"
    #msg -bar
    ;;
  esac