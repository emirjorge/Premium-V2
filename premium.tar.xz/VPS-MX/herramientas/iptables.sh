#!/bin/bash
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )
pid_iptables=$(dpkg -l | grep iptables | grep ii)

# Eliminar todas las reglas
eliminar_reglas() {
if [[ -z "$pid_iptables" ]]; then
    echo -e "${cor[5]} Iptables\033[1;31m NO INSTALADO \e[0m"
    sleep 0.2
    exit 0
fi
iptables -F
iptables -X
sudo sed -i '/^\/sbin\/iptables-restore < \/etc\/iptables\/rules.v4$/d' /etc/rc.local

}

mi_ip() {
    if [[ -e /etc/VPS-MX/MEUIPvps ]]; then
        echo "$(cat /etc/VPS-MX/MEUIPvps)"
    else
        MEU_IP=$(wget -qO- ifconfig.me/ip)
        echo "$MEU_IP" > /etc/VPS-MX/MEUIPvps
    fi
}
instalar_iptables() {
IP4=$(mi_ip)
echo -e "\033[1;32m CONFIGURANDO... \033[0m" | pv -qL10
apt-get update &> /dev/null && echo -e " \033[1;33m[\033[1;34mACTUALIZANDO REPOSITORIOS\033[1;33m] - \033[1;32m100%\033[0m" | pv -qL10
apt-get install iptables -y &> /dev/null && echo -e " \033[1;33m[\033[1;34mINSTALANDO IPTABLES\033[1;33m] - \033[1;32m100%\033[0m" | pv -qL10
# Direcciones IP permitidas
# IP MOVISTAR 190.230.0.0/15 - 190.232.0.0/13
ips_permitidas=(
    $IP4
    190.230.0.0/15
    190.232.0.0/13
)
# Regla para permitir conexiones SSH desde las IPs permitidas
for ip in "${ips_permitidas[@]}"; do
    if ! iptables -C INPUT -p tcp --dport 22 -s $ip -j ACCEPT 2>/dev/null; then
        sudo iptables -A INPUT -p tcp --dport 22 -s $ip -j ACCEPT
    fi
done
# Regla para bloquear todo el tráfico TCP entrante en el puerto 22 no definido
if ! iptables -C INPUT -p tcp --dport 22 -j DROP 2>/dev/null; then
    sudo iptables -A INPUT -p tcp --dport 22 -j DROP
fi
#echo -e "\e[0;31m————————————————————————————————————————————————————————\e[0m"
msg -lol2
echo -e "\e[0;37m       Se creó la regla en Iptables para permitir \e[0m"
echo -e "\e[0;37m       el acceso SSH solo con la IP del VPS \e[0m"
msg -lol2
sudo mkdir -p /etc/iptables
sudo iptables-save > /etc/iptables/rules.v4
# Verificar si la línea ya está presente en /etc/rc.local
if ! grep -q '/sbin/iptables-restore < /etc/iptables/rules.v4' /etc/rc.local; then
    # Si no está presente, agregar la línea
    echo '/sbin/iptables-restore < /etc/iptables/rules.v4' >> /etc/rc.local
fi
#echo -e "\e[0;31m————————————————————————————————————————————————————————\e[0m"
}
agregar_regla() {
echo -ne "\033[1;32m ¿Otorgar acceso a la consola SSH a otra IP?\e[1;97m [s/n]: "
read ip_root
[[ -z $ip_root ]] && ip_root="n"
case $ip_root in
  y|Y|s|S)
    while true; do
      echo -ne "\033[1;32m Por favor ingrese la dirección IP: \e[1;97m"
      read IPv1
      if [[ $IPv1 =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            ultima_linea=$(sudo iptables -L INPUT --line-numbers | tail -n 1 | awk '{print $1}')
            regla_ip="INPUT -p tcp --dport 22 -s $IPv1 -j ACCEPT"
            if iptables -C $regla_ip 2>/dev/null; then
            echo -e " \033[1;37mLa IP \033[1;33m'$IPv1'\033[1;37m ya está añadida en Iptables\e[0m"
            sleep 1
            echo -e " \e[1;92mVerifíquelo usando: \e[1;97miptables -L -n -v \e[0m"
            echo -e "\e[0;31m————————————————————————————————————————————————————————\e[0m"
            sleep 1
            else
            iptables -I INPUT $ultima_linea -p tcp --dport 22 -s $IPv1 -j ACCEPT
            sleep 1
            echo -e " \e[1;92mSe otorgó acceso a la IP: \e[1;97m$IPv1 \e[0m"
            sleep 1
            echo -e " \e[1;92mVerifíquelo usando: \e[1;97miptables -L -n -v \e[0m"
            msg -bar
            sudo mkdir -p /etc/iptables
            sudo iptables-save > /etc/iptables/rules.v4
            # Verificar si la línea ya está presente en /etc/rc.local
            if ! grep -q '/sbin/iptables-restore < /etc/iptables/rules.v4' /etc/rc.local; then
                # Si no está presente, agregar la línea
                echo '/sbin/iptables-restore < /etc/iptables/rules.v4' >> /etc/rc.local
            fi
            sleep 1
            fi
            break
      else
      echo -e "\e[1;91m IP con formato no válido, Inténtelo de nuevo... \e[0m"
      fi
    done
    ;;
  *)
    sleep 0.5
    echo -e "\e[0;91m * No se otorgará el acceso a otra IP * \e[0m"
    msg -bar
    sleep 0.5

    ;;
esac
}
eliminar_regla() {
clear
clear
num_reglas=$(iptables -L INPUT --line-numbers | grep -v Chain | grep -v num | wc -l)
msg -tit
echo -e "\e[1;97m    Eliminar IP para revocar acceso a consola (SSH) \e[0m"
if [[ -z "$pid_iptables" ]]; then
    echo -e "${cor[5]} Iptables\033[1;31m NO INSTALADO \e[0m"
    sleep 0.2
    exit 0
fi
msg -bar
echo -e "\e[1;92m               Nº REGLAS DE ENTRADA\e[1;97m INPUT \e[0m"
msg -bar
iptables -L INPUT -n -v --line-numbers | awk '/Chain/ {print $0} !/Chain/ {printf " %-4s%-8s%-22s%-10s%-10s\n", $1, $4, $9, $11, $12}'

msg -bar
echo -ne " Seleccione una opción [CANCELAR 0]: "
read dig_num
# Verificar si dig_num es un número
if ! [[ "$dig_num" =~ ^[0-9]+$ ]]; then
    echo -e "\e[1;91m Opción no válida \e[0m"
    msg -bar
    sleep 0.2
    msg -ne " Enter Para Continuar" && read enter
    exit 1
elif [ $dig_num -eq 0 ]; then
    echo -e "\e[1;91m CANCELANDO... \e[0m"
    msg -bar
    sleep 0.2
    msg -ne " Enter Para Continuar" && read enter
    exit 1
elif [ $dig_num -le $num_reglas ]; then
    iptables -D INPUT $dig_num
    echo -e "\e[1;92m Se eliminó la regla\e[1;91m Nº $dig_num\e[1;92m con éxito \e[0m"
    msg -bar
    sudo mkdir -p /etc/iptables
    sudo iptables-save > /etc/iptables/rules.v4
    # Verificar si la línea ya está presente en /etc/rc.local
    if ! grep -q '/sbin/iptables-restore < /etc/iptables/rules.v4' /etc/rc.local; then
        # Si no está presente, agregar la línea
        echo '/sbin/iptables-restore < /etc/iptables/rules.v4' >> /etc/rc.local
    fi
    sleep 0.2
else
    echo -e "\e[1;91m Por favor elija una opción válida \e[0m"
    msg -bar
    sleep 0.2
fi
}
################################################################
clear
clear
msg -tit
echo -e "\e[93m              Iptables Protection para SSH"
echo -e "\e[93m         Evitar el Login root a intrusos y Bots"
echo -e "\e[97m           Anti ataques DDOS y spoofing SPAM"
msg -bar
echo -e " \e[1;93m[\e[92m1\e[93m] $(msg -verm2 "➛ ")\e[1;97m Dar acceso a consola (SSH) solo con IP del VPS"
echo -e " \e[1;93m[\e[92m2\e[93m] $(msg -verm2 "➛ ")\e[1;97m Añadir acceso a la consola (SSH) a un IP"
echo -e " \e[1;93m[\e[92m3\e[93m] $(msg -verm2 "➛ ")\e[1;97m Eliminar el acceso a la consola (SSH) a un IP"
echo -e " \e[1;93m[\e[92m4\e[93m] $(msg -verm2 "➛ ")\e[1;93m Ver todas las reglas de Iptables"
echo -e " \e[1;93m[\e[92m5\e[93m] $(msg -verm2 "➛ ")\e[1;91m Eliminar todas las reglas de Iptables"
echo -e "${cor[2]} [0] $(msg -verm2 "➛ ")\e[1;91m Salir 💨 "
msg -bar
    while [[ -z ${Ip_tablesSSH} || ${Ip_tablesSSH} != @(*|1|2|3|4|5) ]]; do
        echo -ne "\033[1;37m$(fun_trans " Seleccione una Opcion"): \033[1;32m" && read Ip_tablesSSH
        tput cuu1 && tput dl1
    done
    case ${Ip_tablesSSH} in
        1)  
            clear
            clear
            msg -tit
            echo -e "\e[1;97m       Acceso a consola (SSH) solo con IP del VPS \e[0m"
            msg -bar 
            IP4=$(mi_ip)
            regla_ipvps="INPUT -p tcp --dport 22 -s $IP4 -j ACCEPT"
            if iptables -C $regla_ipvps 2>/dev/null; then
            echo -e " \033[1;37mLa IP del VPS \033[1;33m'$IP4'\033[1;37m ya está añadida en Iptables\e[0m"
            sleep 1
            echo -e " \e[1;92mVerifíquelo usando: \e[1;97miptables -L -n -v \e[0m"
            msg -bar
            sleep 1
            else
            instalar_iptables
            agregar_regla
            fi
            ;;
        2) 
            clear 
            clear
            msg -tit
            echo -e "\e[1;97m       Añadir IP para dar acceso a consola (SSH) \e[0m"
            msg -bar
            if [[ -z "$pid_iptables" ]]; then
                echo -ne "${cor[5]} Iptables \033[1;31mNO INSTALADO\033[1;37m ¿Desea Instalar Iptables?\e[1;97m [s/n]: "
                read inst_ipt
                if [[ "$inst_ipt" = @(s|S|y|Y) ]]; then
                instalar_iptables
                else
                echo -e "No se realizaron cambios"
                fi
            fi
            agregar_regla
            ;;
        3)  
            eliminar_regla
            sleep 2
            ;;

        4)
           clear
           clear 
           msg -tit
           echo -e "                   REGLAS DE IPTABLES"
           if [[ -z "$pid_iptables" ]]; then
                echo -e "${cor[5]} Iptables\033[1;31m NO INSTALADO \e[0m"
                sleep 0.2
                exit 0
           fi
           msg -bar1
           iptables -L -n -v --line-numbers | awk '/Chain/ {print $0} !/Chain/ {printf " %-4s%-8s%-22s%-10s%-10s\n", $1, $4, $9, $11, $12}'
           msg -bar1
           ;;
        5) 
           eliminar_reglas
           echo -e " Se eliminaron TODAS las reglas en Iptables"
           msg -bar
           sleep 1.5
           ;;
        *) 
           exit 0
        ;;
    esac
    exit 0
